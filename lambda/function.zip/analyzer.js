"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.analyzeWebsite = analyzeWebsite;
const jsdom_1 = require("jsdom");
const ai_service_1 = require("./ai-service");
const content_extractor_1 = require("./content-extractor");
/**
 * Analyze a website by fetching and processing its content
 */
async function analyzeWebsite(url) {
    const startTime = Date.now();
    // Step 1: Fetch website content
    console.log(`Fetching content from ${url}`);
    const fetchStartTime = Date.now();
    const content = await fetchContent(url);
    const fetchTime = Date.now() - fetchStartTime;
    if (!content) {
        throw new Error(`Failed to fetch content from ${url}`);
    }
    // Step 2: Smart content extraction (NEW)
    console.log('Extracting priority content for analysis');
    const extractedContent = (0, content_extractor_1.extractPriorityContent)(content, url);
    console.log(`Extracted ${extractedContent.wordCount} priority words from ${extractedContent.contentType} content`);
    // Step 3: Extract structured content from HTML (for basic analysis)
    console.log('Extracting content structure for basic metrics');
    const legacyContent = extractContent(content);
    // Step 4: Perform basic content analysis
    console.log('Performing basic content analysis');
    const basicAnalysis = performBasicAnalysis(legacyContent);
    // Step 5: Perform enhanced AI-powered analysis
    let aiAnalysis = null;
    let aiRecommendations = null;
    let aiScore = 0;
    let quickWins = null;
    const analysisStartTime = Date.now();
    if (process.env.OPENAI_API_KEY) {
        try {
            console.log(`Performing enhanced AI analysis for ${extractedContent.contentType} content`);
            // Use enhanced AI analysis with smart content extraction
            const aiResult = await (0, ai_service_1.analyzeWithAI)(extractedContent, url);
            // Set AI analysis data if available
            if (aiResult) {
                aiAnalysis = aiResult.areas;
                aiRecommendations = aiResult.suggestions;
                quickWins = aiResult.quick_wins;
                aiScore = Math.min(100, Math.max(0, aiResult.overall_score * 10));
                console.log(`Enhanced AI analysis completed with score: ${aiScore} for ${aiResult.industry} ${aiResult.content_type}`);
            }
        }
        catch (error) {
            console.error('Error in enhanced AI analysis:', error);
            // Continue with only basic analysis if AI fails
        }
    }
    else {
        console.log('OPENAI_API_KEY not set, skipping AI analysis');
    }
    const analysisTime = Date.now() - analysisStartTime;
    const totalTime = Date.now() - startTime;
    // Step 6: Calculate overall score using AI and basic scores
    const overallScore = calculateOverallScore(basicAnalysis.scores, aiScore);
    // Step 7: Return enhanced results
    return {
        url,
        timestamp: new Date().toISOString(),
        scores: {
            ...basicAnalysis.scores,
            overallScore,
            aiAnalysisScore: aiScore || undefined
        },
        recommendations: basicAnalysis.recommendations,
        aiRecommendations: aiRecommendations || undefined,
        details: {
            ...basicAnalysis.details,
            aiAnalysis: aiAnalysis || undefined,
            contentType: extractedContent.contentType,
            industry: aiAnalysis ? aiAnalysis.industry : undefined,
            extractedContent: extractedContent // Include for debugging/future use
        },
        performance: {
            fetchTimeMs: fetchTime,
            analysisTimeMs: analysisTime,
            totalTimeMs: totalTime
        }
    };
}
/**
 * Fetch content from a URL
 */
async function fetchContent(url) {
    try {
        const response = await fetch(url, {
            headers: {
                'User-Agent': 'Aelora-Bot/1.0 (+https://aelora.vercel.app/bot)',
            },
            redirect: 'follow',
        });
        if (!response.ok) {
            console.error(`Failed to fetch ${url}: ${response.status} ${response.statusText}`);
            return null;
        }
        return await response.text();
    }
    catch (error) {
        console.error(`Error fetching ${url}:`, error);
        return null;
    }
}
/**
 * Extract structured content from HTML
 */
function extractContent(html) {
    try {
        const dom = new jsdom_1.JSDOM(html);
        const document = dom.window.document;
        // Extract text content
        const mainContent = document.body.textContent || '';
        // Extract headings
        const headings = Array.from(document.querySelectorAll('h1, h2, h3, h4, h5, h6')).map(heading => ({
            level: parseInt(heading.tagName.substring(1)),
            text: heading.textContent || ''
        }));
        // Extract images
        const images = Array.from(document.querySelectorAll('img')).map(img => ({
            src: img.getAttribute('src') || '',
            alt: img.getAttribute('alt') || ''
        }));
        // Extract schema markup
        const schemas = Array.from(document.querySelectorAll('script[type="application/ld+json"]'))
            .map(script => script.textContent || '');
        // Basic content stats
        const paragraphs = document.querySelectorAll('p').length;
        const lists = document.querySelectorAll('ul, ol').length;
        const tables = document.querySelectorAll('table').length;
        const title = document.querySelector('title')?.textContent || '';
        // Approximate word count
        const wordCount = mainContent.split(/\s+/).filter(Boolean).length;
        return {
            mainContent,
            headings,
            images,
            schemas,
            paragraphs,
            lists,
            tables,
            title,
            wordCount
        };
    }
    catch (error) {
        console.error('Error extracting content:', error);
        return {
            mainContent: '',
            headings: [],
            images: [],
            schemas: [],
            paragraphs: 0,
            lists: 0,
            tables: 0,
            title: '',
            wordCount: 0
        };
    }
}
/**
 * Perform basic content analysis
 */
function performBasicAnalysis(content) {
    // Calculate readability metrics
    const readabilityMetrics = calculateReadabilityMetrics(content.mainContent);
    const readabilityScore = Math.min(100, Math.max(0, 100 - (readabilityMetrics.sentenceLength * 2)));
    // Calculate schema markup score
    const schemaScore = content.schemas.length > 0 ? 85 : 55;
    // Calculate headings structure score
    const headingScore = Math.min(100, Math.max(0, 60 + content.headings.length * 5));
    // Calculate question-answer match score
    const questionAnswerScore = 75; // Fixed score for MVP
    // Generate recommendations
    const recommendations = generateRecommendations(content, readabilityScore, schemaScore, headingScore);
    return {
        scores: {
            readability: readabilityScore,
            schema: schemaScore,
            headingsStructure: headingScore,
            questionAnswerMatch: questionAnswerScore
        },
        recommendations,
        details: {
            wordCount: content.wordCount,
            hasSchema: content.schemas.length > 0,
            headingCount: content.headings.length,
            imageCount: content.images.length,
            imageAltTextRate: calculateImageAltTextRate(content.images),
            readabilityMetrics: {
                sentenceLength: readabilityMetrics.sentenceLength,
                wordLength: readabilityMetrics.wordLength
            }
        }
    };
}
/**
 * Calculate readability metrics
 */
function calculateReadabilityMetrics(text) {
    // Default values for empty content
    if (!text || text.trim().length === 0) {
        return { sentenceLength: 0, wordLength: 0 };
    }
    // Split into sentences and words
    const sentences = text.split(/[.!?]+/).filter(Boolean);
    const words = text.split(/\s+/).filter(Boolean);
    if (sentences.length === 0 || words.length === 0) {
        return { sentenceLength: 0, wordLength: 0 };
    }
    // Calculate average sentence length
    const avgSentenceLength = words.length / sentences.length;
    // Calculate average word length
    const totalChars = words.reduce((sum, word) => sum + word.length, 0);
    const avgWordLength = totalChars / words.length;
    return {
        sentenceLength: Math.round(avgSentenceLength * 10) / 10,
        wordLength: Math.round(avgWordLength * 10) / 10
    };
}
/**
 * Calculate image alt text rate
 */
function calculateImageAltTextRate(images) {
    if (images.length === 0)
        return 0;
    const imagesWithAlt = images.filter(img => img.alt && img.alt.trim().length > 0);
    return Math.round((imagesWithAlt.length / images.length) * 100);
}
/**
 * Generate recommendations based on analysis
 */
function generateRecommendations(content, readabilityScore, schemaScore, headingScore) {
    const recommendations = [];
    // Schema recommendations
    if (schemaScore < 70) {
        recommendations.push("Add structured data using Schema.org markup to improve AI understanding of your content");
    }
    // Readability recommendations
    if (readabilityScore < 70) {
        recommendations.push("Use shorter sentences and simpler language to improve content readability");
    }
    // Heading recommendations
    if (headingScore < 70) {
        recommendations.push("Improve content organization with clear headings and subheadings");
    }
    // Image recommendations
    if (content.images.length > 0 && calculateImageAltTextRate(content.images) < 80) {
        recommendations.push("Add descriptive alt text to all images for better accessibility and AI understanding");
    }
    // Content length recommendations
    if (content.wordCount < 500) {
        recommendations.push("Expand your content with more detailed information to improve comprehensiveness");
    }
    // Always add a few generic recommendations
    recommendations.push("Include concise answers to common questions in your niche");
    recommendations.push("Use descriptive page titles and meta descriptions");
    return recommendations;
}
/**
 * Calculate overall score using a weighted average
 */
function calculateOverallScore(basicScores, aiScore) {
    // If AI score is available, include it in the calculation
    if (aiScore > 0) {
        return Math.round((basicScores.readability * 0.2) +
            (basicScores.schema * 0.2) +
            (basicScores.headingsStructure * 0.2) +
            (basicScores.questionAnswerMatch * 0.1) +
            (aiScore * 0.3));
    }
    // Otherwise, use only basic scores
    return Math.round((basicScores.readability * 0.25) +
        (basicScores.schema * 0.25) +
        (basicScores.headingsStructure * 0.25) +
        (basicScores.questionAnswerMatch * 0.25));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYW5hbHl6ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9zcmMvYW5hbHl6ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUEwQ0Esd0NBdUZDO0FBaklELGlDQUE4QjtBQUM5Qiw2Q0FBNkM7QUFDN0MsMkRBQStFO0FBcUMvRTs7R0FFRztBQUNJLEtBQUssVUFBVSxjQUFjLENBQUMsR0FBVztJQUM5QyxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7SUFFN0IsZ0NBQWdDO0lBQ2hDLE9BQU8sQ0FBQyxHQUFHLENBQUMseUJBQXlCLEdBQUcsRUFBRSxDQUFDLENBQUM7SUFDNUMsTUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO0lBQ2xDLE1BQU0sT0FBTyxHQUFHLE1BQU0sWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ3hDLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxjQUFjLENBQUM7SUFFOUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ2IsTUFBTSxJQUFJLEtBQUssQ0FBQyxnQ0FBZ0MsR0FBRyxFQUFFLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBRUQseUNBQXlDO0lBQ3pDLE9BQU8sQ0FBQyxHQUFHLENBQUMsMENBQTBDLENBQUMsQ0FBQztJQUN4RCxNQUFNLGdCQUFnQixHQUFHLElBQUEsMENBQXNCLEVBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQzlELE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxnQkFBZ0IsQ0FBQyxTQUFTLHdCQUF3QixnQkFBZ0IsQ0FBQyxXQUFXLFVBQVUsQ0FBQyxDQUFDO0lBRW5ILG9FQUFvRTtJQUNwRSxPQUFPLENBQUMsR0FBRyxDQUFDLGdEQUFnRCxDQUFDLENBQUM7SUFDOUQsTUFBTSxhQUFhLEdBQUcsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBRTlDLHlDQUF5QztJQUN6QyxPQUFPLENBQUMsR0FBRyxDQUFDLG1DQUFtQyxDQUFDLENBQUM7SUFDakQsTUFBTSxhQUFhLEdBQUcsb0JBQW9CLENBQUMsYUFBYSxDQUFDLENBQUM7SUFFMUQsK0NBQStDO0lBQy9DLElBQUksVUFBVSxHQUFHLElBQUksQ0FBQztJQUN0QixJQUFJLGlCQUFpQixHQUFHLElBQUksQ0FBQztJQUM3QixJQUFJLE9BQU8sR0FBRyxDQUFDLENBQUM7SUFDaEIsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDO0lBRXJCLE1BQU0saUJBQWlCLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO0lBRXJDLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUMvQixJQUFJLENBQUM7WUFDSCxPQUFPLENBQUMsR0FBRyxDQUFDLHVDQUF1QyxnQkFBZ0IsQ0FBQyxXQUFXLFVBQVUsQ0FBQyxDQUFDO1lBRTNGLHlEQUF5RDtZQUN6RCxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUEsMEJBQWEsRUFBQyxnQkFBZ0IsRUFBRSxHQUFHLENBQUMsQ0FBQztZQUU1RCxvQ0FBb0M7WUFDcEMsSUFBSSxRQUFRLEVBQUUsQ0FBQztnQkFDYixVQUFVLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQztnQkFDNUIsaUJBQWlCLEdBQUcsUUFBUSxDQUFDLFdBQVcsQ0FBQztnQkFDekMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxVQUFVLENBQUM7Z0JBQ2hDLE9BQU8sR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ2xFLE9BQU8sQ0FBQyxHQUFHLENBQUMsOENBQThDLE9BQU8sUUFBUSxRQUFRLENBQUMsUUFBUSxJQUFJLFFBQVEsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDO1lBQ3pILENBQUM7UUFDSCxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsZ0NBQWdDLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDdkQsZ0RBQWdEO1FBQ2xELENBQUM7SUFDSCxDQUFDO1NBQU0sQ0FBQztRQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMsOENBQThDLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBRUQsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLGlCQUFpQixDQUFDO0lBQ3BELE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxTQUFTLENBQUM7SUFFekMsNERBQTREO0lBQzVELE1BQU0sWUFBWSxHQUFHLHFCQUFxQixDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFFMUUsa0NBQWtDO0lBQ2xDLE9BQU87UUFDTCxHQUFHO1FBQ0gsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO1FBQ25DLE1BQU0sRUFBRTtZQUNOLEdBQUcsYUFBYSxDQUFDLE1BQU07WUFDdkIsWUFBWTtZQUNaLGVBQWUsRUFBRSxPQUFPLElBQUksU0FBUztTQUN0QztRQUNELGVBQWUsRUFBRSxhQUFhLENBQUMsZUFBZTtRQUM5QyxpQkFBaUIsRUFBRSxpQkFBaUIsSUFBSSxTQUFTO1FBQ2pELE9BQU8sRUFBRTtZQUNQLEdBQUcsYUFBYSxDQUFDLE9BQU87WUFDeEIsVUFBVSxFQUFFLFVBQVUsSUFBSSxTQUFTO1lBQ25DLFdBQVcsRUFBRSxnQkFBZ0IsQ0FBQyxXQUFXO1lBQ3pDLFFBQVEsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFFLFVBQWtCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTO1lBQy9ELGdCQUFnQixFQUFFLGdCQUFnQixDQUFDLG1DQUFtQztTQUN2RTtRQUNELFdBQVcsRUFBRTtZQUNYLFdBQVcsRUFBRSxTQUFTO1lBQ3RCLGNBQWMsRUFBRSxZQUFZO1lBQzVCLFdBQVcsRUFBRSxTQUFTO1NBQ3ZCO0tBQ0YsQ0FBQztBQUNKLENBQUM7QUFFRDs7R0FFRztBQUNILEtBQUssVUFBVSxZQUFZLENBQUMsR0FBVztJQUNyQyxJQUFJLENBQUM7UUFDSCxNQUFNLFFBQVEsR0FBRyxNQUFNLEtBQUssQ0FBQyxHQUFHLEVBQUU7WUFDaEMsT0FBTyxFQUFFO2dCQUNQLFlBQVksRUFBRSxpREFBaUQ7YUFDaEU7WUFDRCxRQUFRLEVBQUUsUUFBUTtTQUNuQixDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxDQUFDO1lBQ2pCLE9BQU8sQ0FBQyxLQUFLLENBQUMsbUJBQW1CLEdBQUcsS0FBSyxRQUFRLENBQUMsTUFBTSxJQUFJLFFBQVEsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDO1lBQ25GLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUVELE9BQU8sTUFBTSxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDL0IsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLGtCQUFrQixHQUFHLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUMvQyxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7QUFDSCxDQUFDO0FBRUQ7O0dBRUc7QUFDSCxTQUFTLGNBQWMsQ0FBQyxJQUFZO0lBQ2xDLElBQUksQ0FBQztRQUNILE1BQU0sR0FBRyxHQUFHLElBQUksYUFBSyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzVCLE1BQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO1FBRXJDLHVCQUF1QjtRQUN2QixNQUFNLFdBQVcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsSUFBSSxFQUFFLENBQUM7UUFFcEQsbUJBQW1CO1FBQ25CLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQy9GLEtBQUssRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDN0MsSUFBSSxFQUFFLE9BQU8sQ0FBQyxXQUFXLElBQUksRUFBRTtTQUNoQyxDQUFDLENBQUMsQ0FBQztRQUVKLGlCQUFpQjtRQUNqQixNQUFNLE1BQU0sR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDdEUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRTtZQUNsQyxHQUFHLEVBQUUsR0FBRyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFO1NBQ25DLENBQUMsQ0FBQyxDQUFDO1FBRUosd0JBQXdCO1FBQ3hCLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLG9DQUFvQyxDQUFDLENBQUM7YUFDeEYsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUUzQyxzQkFBc0I7UUFDdEIsTUFBTSxVQUFVLEdBQUcsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUN6RCxNQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDO1FBQ3pELE1BQU0sTUFBTSxHQUFHLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUM7UUFDekQsTUFBTSxLQUFLLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsRUFBRSxXQUFXLElBQUksRUFBRSxDQUFDO1FBRWpFLHlCQUF5QjtRQUN6QixNQUFNLFNBQVMsR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUM7UUFFbEUsT0FBTztZQUNMLFdBQVc7WUFDWCxRQUFRO1lBQ1IsTUFBTTtZQUNOLE9BQU87WUFDUCxVQUFVO1lBQ1YsS0FBSztZQUNMLE1BQU07WUFDTixLQUFLO1lBQ0wsU0FBUztTQUNWLENBQUM7SUFDSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsMkJBQTJCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDbEQsT0FBTztZQUNMLFdBQVcsRUFBRSxFQUFFO1lBQ2YsUUFBUSxFQUFFLEVBQUU7WUFDWixNQUFNLEVBQUUsRUFBRTtZQUNWLE9BQU8sRUFBRSxFQUFFO1lBQ1gsVUFBVSxFQUFFLENBQUM7WUFDYixLQUFLLEVBQUUsQ0FBQztZQUNSLE1BQU0sRUFBRSxDQUFDO1lBQ1QsS0FBSyxFQUFFLEVBQUU7WUFDVCxTQUFTLEVBQUUsQ0FBQztTQUNiLENBQUM7SUFDSixDQUFDO0FBQ0gsQ0FBQztBQUVEOztHQUVHO0FBQ0gsU0FBUyxvQkFBb0IsQ0FBQyxPQUFZO0lBQ3hDLGdDQUFnQztJQUNoQyxNQUFNLGtCQUFrQixHQUFHLDJCQUEyQixDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUM1RSxNQUFNLGdCQUFnQixHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsR0FBRyxDQUFDLGtCQUFrQixDQUFDLGNBQWMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFFbkcsZ0NBQWdDO0lBQ2hDLE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7SUFFekQscUNBQXFDO0lBQ3JDLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQUUsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBRWxGLHdDQUF3QztJQUN4QyxNQUFNLG1CQUFtQixHQUFHLEVBQUUsQ0FBQyxDQUFDLHNCQUFzQjtJQUV0RCwyQkFBMkI7SUFDM0IsTUFBTSxlQUFlLEdBQUcsdUJBQXVCLENBQUMsT0FBTyxFQUFFLGdCQUFnQixFQUFFLFdBQVcsRUFBRSxZQUFZLENBQUMsQ0FBQztJQUV0RyxPQUFPO1FBQ0wsTUFBTSxFQUFFO1lBQ04sV0FBVyxFQUFFLGdCQUFnQjtZQUM3QixNQUFNLEVBQUUsV0FBVztZQUNuQixpQkFBaUIsRUFBRSxZQUFZO1lBQy9CLG1CQUFtQixFQUFFLG1CQUFtQjtTQUN6QztRQUNELGVBQWU7UUFDZixPQUFPLEVBQUU7WUFDUCxTQUFTLEVBQUUsT0FBTyxDQUFDLFNBQVM7WUFDNUIsU0FBUyxFQUFFLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUM7WUFDckMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxRQUFRLENBQUMsTUFBTTtZQUNyQyxVQUFVLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxNQUFNO1lBQ2pDLGdCQUFnQixFQUFFLHlCQUF5QixDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUM7WUFDM0Qsa0JBQWtCLEVBQUU7Z0JBQ2xCLGNBQWMsRUFBRSxrQkFBa0IsQ0FBQyxjQUFjO2dCQUNqRCxVQUFVLEVBQUUsa0JBQWtCLENBQUMsVUFBVTthQUMxQztTQUNGO0tBQ0YsQ0FBQztBQUNKLENBQUM7QUFFRDs7R0FFRztBQUNILFNBQVMsMkJBQTJCLENBQUMsSUFBWTtJQUMvQyxtQ0FBbUM7SUFDbkMsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1FBQ3RDLE9BQU8sRUFBRSxjQUFjLEVBQUUsQ0FBQyxFQUFFLFVBQVUsRUFBRSxDQUFDLEVBQUUsQ0FBQztJQUM5QyxDQUFDO0lBRUQsaUNBQWlDO0lBQ2pDLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3ZELE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBRWhELElBQUksU0FBUyxDQUFDLE1BQU0sS0FBSyxDQUFDLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztRQUNqRCxPQUFPLEVBQUUsY0FBYyxFQUFFLENBQUMsRUFBRSxVQUFVLEVBQUUsQ0FBQyxFQUFFLENBQUM7SUFDOUMsQ0FBQztJQUVELG9DQUFvQztJQUNwQyxNQUFNLGlCQUFpQixHQUFHLEtBQUssQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQztJQUUxRCxnQ0FBZ0M7SUFDaEMsTUFBTSxVQUFVLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ3JFLE1BQU0sYUFBYSxHQUFHLFVBQVUsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO0lBRWhELE9BQU87UUFDTCxjQUFjLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFO1FBQ3ZELFVBQVUsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFO0tBQ2hELENBQUM7QUFDSixDQUFDO0FBRUQ7O0dBRUc7QUFDSCxTQUFTLHlCQUF5QixDQUFDLE1BQXNDO0lBQ3ZFLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxDQUFDO1FBQUUsT0FBTyxDQUFDLENBQUM7SUFFbEMsTUFBTSxhQUFhLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDakYsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsYUFBYSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7QUFDbEUsQ0FBQztBQUVEOztHQUVHO0FBQ0gsU0FBUyx1QkFBdUIsQ0FBQyxPQUFZLEVBQUUsZ0JBQXdCLEVBQUUsV0FBbUIsRUFBRSxZQUFvQjtJQUNoSCxNQUFNLGVBQWUsR0FBYSxFQUFFLENBQUM7SUFFckMseUJBQXlCO0lBQ3pCLElBQUksV0FBVyxHQUFHLEVBQUUsRUFBRSxDQUFDO1FBQ3JCLGVBQWUsQ0FBQyxJQUFJLENBQUMseUZBQXlGLENBQUMsQ0FBQztJQUNsSCxDQUFDO0lBRUQsOEJBQThCO0lBQzlCLElBQUksZ0JBQWdCLEdBQUcsRUFBRSxFQUFFLENBQUM7UUFDMUIsZUFBZSxDQUFDLElBQUksQ0FBQywyRUFBMkUsQ0FBQyxDQUFDO0lBQ3BHLENBQUM7SUFFRCwwQkFBMEI7SUFDMUIsSUFBSSxZQUFZLEdBQUcsRUFBRSxFQUFFLENBQUM7UUFDdEIsZUFBZSxDQUFDLElBQUksQ0FBQyxrRUFBa0UsQ0FBQyxDQUFDO0lBQzNGLENBQUM7SUFFRCx3QkFBd0I7SUFDeEIsSUFBSSxPQUFPLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUkseUJBQXlCLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDO1FBQ2hGLGVBQWUsQ0FBQyxJQUFJLENBQUMsc0ZBQXNGLENBQUMsQ0FBQztJQUMvRyxDQUFDO0lBRUQsaUNBQWlDO0lBQ2pDLElBQUksT0FBTyxDQUFDLFNBQVMsR0FBRyxHQUFHLEVBQUUsQ0FBQztRQUM1QixlQUFlLENBQUMsSUFBSSxDQUFDLGlGQUFpRixDQUFDLENBQUM7SUFDMUcsQ0FBQztJQUVELDJDQUEyQztJQUMzQyxlQUFlLENBQUMsSUFBSSxDQUFDLDJEQUEyRCxDQUFDLENBQUM7SUFDbEYsZUFBZSxDQUFDLElBQUksQ0FBQyxtREFBbUQsQ0FBQyxDQUFDO0lBRTFFLE9BQU8sZUFBZSxDQUFDO0FBQ3pCLENBQUM7QUFFRDs7R0FFRztBQUNILFNBQVMscUJBQXFCLENBQUMsV0FBZ0IsRUFBRSxPQUFlO0lBQzlELDBEQUEwRDtJQUMxRCxJQUFJLE9BQU8sR0FBRyxDQUFDLEVBQUUsQ0FBQztRQUNoQixPQUFPLElBQUksQ0FBQyxLQUFLLENBQ2YsQ0FBQyxXQUFXLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQztZQUMvQixDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDO1lBQzFCLENBQUMsV0FBVyxDQUFDLGlCQUFpQixHQUFHLEdBQUcsQ0FBQztZQUNyQyxDQUFDLFdBQVcsQ0FBQyxtQkFBbUIsR0FBRyxHQUFHLENBQUM7WUFDdkMsQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDLENBQ2hCLENBQUM7SUFDSixDQUFDO0lBRUQsbUNBQW1DO0lBQ25DLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FDZixDQUFDLFdBQVcsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO1FBQ2hDLENBQUMsV0FBVyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7UUFDM0IsQ0FBQyxXQUFXLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO1FBQ3RDLENBQUMsV0FBVyxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQyxDQUN6QyxDQUFDO0FBQ0osQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEpTRE9NIH0gZnJvbSAnanNkb20nO1xuaW1wb3J0IHsgYW5hbHl6ZVdpdGhBSSB9IGZyb20gJy4vYWktc2VydmljZSc7XG5pbXBvcnQgeyBleHRyYWN0UHJpb3JpdHlDb250ZW50LCBFeHRyYWN0ZWRDb250ZW50IH0gZnJvbSAnLi9jb250ZW50LWV4dHJhY3Rvcic7XG5cbmludGVyZmFjZSBBbmFseXNpc1Jlc3VsdCB7XG4gIHVybDogc3RyaW5nO1xuICB0aW1lc3RhbXA6IHN0cmluZztcbiAgc2NvcmVzOiB7XG4gICAgcmVhZGFiaWxpdHk6IG51bWJlcjtcbiAgICBzY2hlbWE6IG51bWJlcjtcbiAgICBxdWVzdGlvbkFuc3dlck1hdGNoOiBudW1iZXI7XG4gICAgaGVhZGluZ3NTdHJ1Y3R1cmU6IG51bWJlcjtcbiAgICBvdmVyYWxsU2NvcmU6IG51bWJlcjtcbiAgICBhaUFuYWx5c2lzU2NvcmU/OiBudW1iZXI7XG4gIH07XG4gIHJlY29tbWVuZGF0aW9uczogc3RyaW5nW107XG4gIGFpUmVjb21tZW5kYXRpb25zPzogYW55W107XG4gIGRldGFpbHM6IHtcbiAgICB3b3JkQ291bnQ6IG51bWJlcjtcbiAgICBoYXNTY2hlbWE6IGJvb2xlYW47XG4gICAgaGVhZGluZ0NvdW50OiBudW1iZXI7XG4gICAgaW1hZ2VDb3VudDogbnVtYmVyO1xuICAgIGltYWdlQWx0VGV4dFJhdGU6IG51bWJlcjtcbiAgICByZWFkYWJpbGl0eU1ldHJpY3M6IHtcbiAgICAgIHNlbnRlbmNlTGVuZ3RoOiBudW1iZXI7XG4gICAgICB3b3JkTGVuZ3RoOiBudW1iZXI7XG4gICAgfTtcbiAgICBhaUFuYWx5c2lzPzogYW55O1xuICAgIGNvbnRlbnRUeXBlPzogc3RyaW5nO1xuICAgIGluZHVzdHJ5Pzogc3RyaW5nO1xuICAgIGV4dHJhY3RlZENvbnRlbnQ/OiBFeHRyYWN0ZWRDb250ZW50O1xuICB9O1xuICBwZXJmb3JtYW5jZT86IHtcbiAgICBmZXRjaFRpbWVNczogbnVtYmVyO1xuICAgIGFuYWx5c2lzVGltZU1zOiBudW1iZXI7XG4gICAgdG90YWxUaW1lTXM6IG51bWJlcjtcbiAgfTtcbn1cblxuLyoqXG4gKiBBbmFseXplIGEgd2Vic2l0ZSBieSBmZXRjaGluZyBhbmQgcHJvY2Vzc2luZyBpdHMgY29udGVudFxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYW5hbHl6ZVdlYnNpdGUodXJsOiBzdHJpbmcpOiBQcm9taXNlPEFuYWx5c2lzUmVzdWx0PiB7XG4gIGNvbnN0IHN0YXJ0VGltZSA9IERhdGUubm93KCk7XG4gIFxuICAvLyBTdGVwIDE6IEZldGNoIHdlYnNpdGUgY29udGVudFxuICBjb25zb2xlLmxvZyhgRmV0Y2hpbmcgY29udGVudCBmcm9tICR7dXJsfWApO1xuICBjb25zdCBmZXRjaFN0YXJ0VGltZSA9IERhdGUubm93KCk7XG4gIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCBmZXRjaENvbnRlbnQodXJsKTtcbiAgY29uc3QgZmV0Y2hUaW1lID0gRGF0ZS5ub3coKSAtIGZldGNoU3RhcnRUaW1lO1xuICBcbiAgaWYgKCFjb250ZW50KSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gZmV0Y2ggY29udGVudCBmcm9tICR7dXJsfWApO1xuICB9XG4gIFxuICAvLyBTdGVwIDI6IFNtYXJ0IGNvbnRlbnQgZXh0cmFjdGlvbiAoTkVXKVxuICBjb25zb2xlLmxvZygnRXh0cmFjdGluZyBwcmlvcml0eSBjb250ZW50IGZvciBhbmFseXNpcycpO1xuICBjb25zdCBleHRyYWN0ZWRDb250ZW50ID0gZXh0cmFjdFByaW9yaXR5Q29udGVudChjb250ZW50LCB1cmwpO1xuICBjb25zb2xlLmxvZyhgRXh0cmFjdGVkICR7ZXh0cmFjdGVkQ29udGVudC53b3JkQ291bnR9IHByaW9yaXR5IHdvcmRzIGZyb20gJHtleHRyYWN0ZWRDb250ZW50LmNvbnRlbnRUeXBlfSBjb250ZW50YCk7XG4gIFxuICAvLyBTdGVwIDM6IEV4dHJhY3Qgc3RydWN0dXJlZCBjb250ZW50IGZyb20gSFRNTCAoZm9yIGJhc2ljIGFuYWx5c2lzKVxuICBjb25zb2xlLmxvZygnRXh0cmFjdGluZyBjb250ZW50IHN0cnVjdHVyZSBmb3IgYmFzaWMgbWV0cmljcycpO1xuICBjb25zdCBsZWdhY3lDb250ZW50ID0gZXh0cmFjdENvbnRlbnQoY29udGVudCk7XG4gIFxuICAvLyBTdGVwIDQ6IFBlcmZvcm0gYmFzaWMgY29udGVudCBhbmFseXNpc1xuICBjb25zb2xlLmxvZygnUGVyZm9ybWluZyBiYXNpYyBjb250ZW50IGFuYWx5c2lzJyk7XG4gIGNvbnN0IGJhc2ljQW5hbHlzaXMgPSBwZXJmb3JtQmFzaWNBbmFseXNpcyhsZWdhY3lDb250ZW50KTtcbiAgXG4gIC8vIFN0ZXAgNTogUGVyZm9ybSBlbmhhbmNlZCBBSS1wb3dlcmVkIGFuYWx5c2lzXG4gIGxldCBhaUFuYWx5c2lzID0gbnVsbDtcbiAgbGV0IGFpUmVjb21tZW5kYXRpb25zID0gbnVsbDtcbiAgbGV0IGFpU2NvcmUgPSAwO1xuICBsZXQgcXVpY2tXaW5zID0gbnVsbDtcbiAgXG4gIGNvbnN0IGFuYWx5c2lzU3RhcnRUaW1lID0gRGF0ZS5ub3coKTtcbiAgXG4gIGlmIChwcm9jZXNzLmVudi5PUEVOQUlfQVBJX0tFWSkge1xuICAgIHRyeSB7XG4gICAgICBjb25zb2xlLmxvZyhgUGVyZm9ybWluZyBlbmhhbmNlZCBBSSBhbmFseXNpcyBmb3IgJHtleHRyYWN0ZWRDb250ZW50LmNvbnRlbnRUeXBlfSBjb250ZW50YCk7XG4gICAgICBcbiAgICAgIC8vIFVzZSBlbmhhbmNlZCBBSSBhbmFseXNpcyB3aXRoIHNtYXJ0IGNvbnRlbnQgZXh0cmFjdGlvblxuICAgICAgY29uc3QgYWlSZXN1bHQgPSBhd2FpdCBhbmFseXplV2l0aEFJKGV4dHJhY3RlZENvbnRlbnQsIHVybCk7XG4gICAgICBcbiAgICAgIC8vIFNldCBBSSBhbmFseXNpcyBkYXRhIGlmIGF2YWlsYWJsZVxuICAgICAgaWYgKGFpUmVzdWx0KSB7XG4gICAgICAgIGFpQW5hbHlzaXMgPSBhaVJlc3VsdC5hcmVhcztcbiAgICAgICAgYWlSZWNvbW1lbmRhdGlvbnMgPSBhaVJlc3VsdC5zdWdnZXN0aW9ucztcbiAgICAgICAgcXVpY2tXaW5zID0gYWlSZXN1bHQucXVpY2tfd2lucztcbiAgICAgICAgYWlTY29yZSA9IE1hdGgubWluKDEwMCwgTWF0aC5tYXgoMCwgYWlSZXN1bHQub3ZlcmFsbF9zY29yZSAqIDEwKSk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBFbmhhbmNlZCBBSSBhbmFseXNpcyBjb21wbGV0ZWQgd2l0aCBzY29yZTogJHthaVNjb3JlfSBmb3IgJHthaVJlc3VsdC5pbmR1c3RyeX0gJHthaVJlc3VsdC5jb250ZW50X3R5cGV9YCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGluIGVuaGFuY2VkIEFJIGFuYWx5c2lzOicsIGVycm9yKTtcbiAgICAgIC8vIENvbnRpbnVlIHdpdGggb25seSBiYXNpYyBhbmFseXNpcyBpZiBBSSBmYWlsc1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBjb25zb2xlLmxvZygnT1BFTkFJX0FQSV9LRVkgbm90IHNldCwgc2tpcHBpbmcgQUkgYW5hbHlzaXMnKTtcbiAgfVxuICBcbiAgY29uc3QgYW5hbHlzaXNUaW1lID0gRGF0ZS5ub3coKSAtIGFuYWx5c2lzU3RhcnRUaW1lO1xuICBjb25zdCB0b3RhbFRpbWUgPSBEYXRlLm5vdygpIC0gc3RhcnRUaW1lO1xuICBcbiAgLy8gU3RlcCA2OiBDYWxjdWxhdGUgb3ZlcmFsbCBzY29yZSB1c2luZyBBSSBhbmQgYmFzaWMgc2NvcmVzXG4gIGNvbnN0IG92ZXJhbGxTY29yZSA9IGNhbGN1bGF0ZU92ZXJhbGxTY29yZShiYXNpY0FuYWx5c2lzLnNjb3JlcywgYWlTY29yZSk7XG4gIFxuICAvLyBTdGVwIDc6IFJldHVybiBlbmhhbmNlZCByZXN1bHRzXG4gIHJldHVybiB7XG4gICAgdXJsLFxuICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHNjb3Jlczoge1xuICAgICAgLi4uYmFzaWNBbmFseXNpcy5zY29yZXMsXG4gICAgICBvdmVyYWxsU2NvcmUsXG4gICAgICBhaUFuYWx5c2lzU2NvcmU6IGFpU2NvcmUgfHwgdW5kZWZpbmVkXG4gICAgfSxcbiAgICByZWNvbW1lbmRhdGlvbnM6IGJhc2ljQW5hbHlzaXMucmVjb21tZW5kYXRpb25zLFxuICAgIGFpUmVjb21tZW5kYXRpb25zOiBhaVJlY29tbWVuZGF0aW9ucyB8fCB1bmRlZmluZWQsXG4gICAgZGV0YWlsczoge1xuICAgICAgLi4uYmFzaWNBbmFseXNpcy5kZXRhaWxzLFxuICAgICAgYWlBbmFseXNpczogYWlBbmFseXNpcyB8fCB1bmRlZmluZWQsXG4gICAgICBjb250ZW50VHlwZTogZXh0cmFjdGVkQ29udGVudC5jb250ZW50VHlwZSxcbiAgICAgIGluZHVzdHJ5OiBhaUFuYWx5c2lzID8gKGFpQW5hbHlzaXMgYXMgYW55KS5pbmR1c3RyeSA6IHVuZGVmaW5lZCxcbiAgICAgIGV4dHJhY3RlZENvbnRlbnQ6IGV4dHJhY3RlZENvbnRlbnQgLy8gSW5jbHVkZSBmb3IgZGVidWdnaW5nL2Z1dHVyZSB1c2VcbiAgICB9LFxuICAgIHBlcmZvcm1hbmNlOiB7XG4gICAgICBmZXRjaFRpbWVNczogZmV0Y2hUaW1lLFxuICAgICAgYW5hbHlzaXNUaW1lTXM6IGFuYWx5c2lzVGltZSxcbiAgICAgIHRvdGFsVGltZU1zOiB0b3RhbFRpbWVcbiAgICB9XG4gIH07XG59XG5cbi8qKlxuICogRmV0Y2ggY29udGVudCBmcm9tIGEgVVJMXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGZldGNoQ29udGVudCh1cmw6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICB0cnkge1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2godXJsLCB7XG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgICdVc2VyLUFnZW50JzogJ0FlbG9yYS1Cb3QvMS4wICgraHR0cHM6Ly9hZWxvcmEudmVyY2VsLmFwcC9ib3QpJyxcbiAgICAgIH0sXG4gICAgICByZWRpcmVjdDogJ2ZvbGxvdycsXG4gICAgfSk7XG4gICAgXG4gICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgY29uc29sZS5lcnJvcihgRmFpbGVkIHRvIGZldGNoICR7dXJsfTogJHtyZXNwb25zZS5zdGF0dXN9ICR7cmVzcG9uc2Uuc3RhdHVzVGV4dH1gKTtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBcbiAgICByZXR1cm4gYXdhaXQgcmVzcG9uc2UudGV4dCgpO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nICR7dXJsfTpgLCBlcnJvcik7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuLyoqXG4gKiBFeHRyYWN0IHN0cnVjdHVyZWQgY29udGVudCBmcm9tIEhUTUxcbiAqL1xuZnVuY3Rpb24gZXh0cmFjdENvbnRlbnQoaHRtbDogc3RyaW5nKTogYW55IHtcbiAgdHJ5IHtcbiAgICBjb25zdCBkb20gPSBuZXcgSlNET00oaHRtbCk7XG4gICAgY29uc3QgZG9jdW1lbnQgPSBkb20ud2luZG93LmRvY3VtZW50O1xuICAgIFxuICAgIC8vIEV4dHJhY3QgdGV4dCBjb250ZW50XG4gICAgY29uc3QgbWFpbkNvbnRlbnQgPSBkb2N1bWVudC5ib2R5LnRleHRDb250ZW50IHx8ICcnO1xuICAgIFxuICAgIC8vIEV4dHJhY3QgaGVhZGluZ3NcbiAgICBjb25zdCBoZWFkaW5ncyA9IEFycmF5LmZyb20oZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnaDEsIGgyLCBoMywgaDQsIGg1LCBoNicpKS5tYXAoaGVhZGluZyA9PiAoe1xuICAgICAgbGV2ZWw6IHBhcnNlSW50KGhlYWRpbmcudGFnTmFtZS5zdWJzdHJpbmcoMSkpLFxuICAgICAgdGV4dDogaGVhZGluZy50ZXh0Q29udGVudCB8fCAnJ1xuICAgIH0pKTtcbiAgICBcbiAgICAvLyBFeHRyYWN0IGltYWdlc1xuICAgIGNvbnN0IGltYWdlcyA9IEFycmF5LmZyb20oZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnaW1nJykpLm1hcChpbWcgPT4gKHtcbiAgICAgIHNyYzogaW1nLmdldEF0dHJpYnV0ZSgnc3JjJykgfHwgJycsXG4gICAgICBhbHQ6IGltZy5nZXRBdHRyaWJ1dGUoJ2FsdCcpIHx8ICcnXG4gICAgfSkpO1xuICAgIFxuICAgIC8vIEV4dHJhY3Qgc2NoZW1hIG1hcmt1cFxuICAgIGNvbnN0IHNjaGVtYXMgPSBBcnJheS5mcm9tKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ3NjcmlwdFt0eXBlPVwiYXBwbGljYXRpb24vbGQranNvblwiXScpKVxuICAgICAgLm1hcChzY3JpcHQgPT4gc2NyaXB0LnRleHRDb250ZW50IHx8ICcnKTtcbiAgICBcbiAgICAvLyBCYXNpYyBjb250ZW50IHN0YXRzXG4gICAgY29uc3QgcGFyYWdyYXBocyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ3AnKS5sZW5ndGg7XG4gICAgY29uc3QgbGlzdHMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCd1bCwgb2wnKS5sZW5ndGg7XG4gICAgY29uc3QgdGFibGVzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgndGFibGUnKS5sZW5ndGg7XG4gICAgY29uc3QgdGl0bGUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCd0aXRsZScpPy50ZXh0Q29udGVudCB8fCAnJztcbiAgICBcbiAgICAvLyBBcHByb3hpbWF0ZSB3b3JkIGNvdW50XG4gICAgY29uc3Qgd29yZENvdW50ID0gbWFpbkNvbnRlbnQuc3BsaXQoL1xccysvKS5maWx0ZXIoQm9vbGVhbikubGVuZ3RoO1xuICAgIFxuICAgIHJldHVybiB7XG4gICAgICBtYWluQ29udGVudCxcbiAgICAgIGhlYWRpbmdzLFxuICAgICAgaW1hZ2VzLFxuICAgICAgc2NoZW1hcyxcbiAgICAgIHBhcmFncmFwaHMsXG4gICAgICBsaXN0cyxcbiAgICAgIHRhYmxlcyxcbiAgICAgIHRpdGxlLFxuICAgICAgd29yZENvdW50XG4gICAgfTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKCdFcnJvciBleHRyYWN0aW5nIGNvbnRlbnQ6JywgZXJyb3IpO1xuICAgIHJldHVybiB7XG4gICAgICBtYWluQ29udGVudDogJycsXG4gICAgICBoZWFkaW5nczogW10sXG4gICAgICBpbWFnZXM6IFtdLFxuICAgICAgc2NoZW1hczogW10sXG4gICAgICBwYXJhZ3JhcGhzOiAwLFxuICAgICAgbGlzdHM6IDAsXG4gICAgICB0YWJsZXM6IDAsXG4gICAgICB0aXRsZTogJycsXG4gICAgICB3b3JkQ291bnQ6IDBcbiAgICB9O1xuICB9XG59XG5cbi8qKlxuICogUGVyZm9ybSBiYXNpYyBjb250ZW50IGFuYWx5c2lzXG4gKi9cbmZ1bmN0aW9uIHBlcmZvcm1CYXNpY0FuYWx5c2lzKGNvbnRlbnQ6IGFueSk6IGFueSB7XG4gIC8vIENhbGN1bGF0ZSByZWFkYWJpbGl0eSBtZXRyaWNzXG4gIGNvbnN0IHJlYWRhYmlsaXR5TWV0cmljcyA9IGNhbGN1bGF0ZVJlYWRhYmlsaXR5TWV0cmljcyhjb250ZW50Lm1haW5Db250ZW50KTtcbiAgY29uc3QgcmVhZGFiaWxpdHlTY29yZSA9IE1hdGgubWluKDEwMCwgTWF0aC5tYXgoMCwgMTAwIC0gKHJlYWRhYmlsaXR5TWV0cmljcy5zZW50ZW5jZUxlbmd0aCAqIDIpKSk7XG4gIFxuICAvLyBDYWxjdWxhdGUgc2NoZW1hIG1hcmt1cCBzY29yZVxuICBjb25zdCBzY2hlbWFTY29yZSA9IGNvbnRlbnQuc2NoZW1hcy5sZW5ndGggPiAwID8gODUgOiA1NTtcbiAgXG4gIC8vIENhbGN1bGF0ZSBoZWFkaW5ncyBzdHJ1Y3R1cmUgc2NvcmVcbiAgY29uc3QgaGVhZGluZ1Njb3JlID0gTWF0aC5taW4oMTAwLCBNYXRoLm1heCgwLCA2MCArIGNvbnRlbnQuaGVhZGluZ3MubGVuZ3RoICogNSkpO1xuICBcbiAgLy8gQ2FsY3VsYXRlIHF1ZXN0aW9uLWFuc3dlciBtYXRjaCBzY29yZVxuICBjb25zdCBxdWVzdGlvbkFuc3dlclNjb3JlID0gNzU7IC8vIEZpeGVkIHNjb3JlIGZvciBNVlBcbiAgXG4gIC8vIEdlbmVyYXRlIHJlY29tbWVuZGF0aW9uc1xuICBjb25zdCByZWNvbW1lbmRhdGlvbnMgPSBnZW5lcmF0ZVJlY29tbWVuZGF0aW9ucyhjb250ZW50LCByZWFkYWJpbGl0eVNjb3JlLCBzY2hlbWFTY29yZSwgaGVhZGluZ1Njb3JlKTtcbiAgXG4gIHJldHVybiB7XG4gICAgc2NvcmVzOiB7XG4gICAgICByZWFkYWJpbGl0eTogcmVhZGFiaWxpdHlTY29yZSxcbiAgICAgIHNjaGVtYTogc2NoZW1hU2NvcmUsXG4gICAgICBoZWFkaW5nc1N0cnVjdHVyZTogaGVhZGluZ1Njb3JlLFxuICAgICAgcXVlc3Rpb25BbnN3ZXJNYXRjaDogcXVlc3Rpb25BbnN3ZXJTY29yZVxuICAgIH0sXG4gICAgcmVjb21tZW5kYXRpb25zLFxuICAgIGRldGFpbHM6IHtcbiAgICAgIHdvcmRDb3VudDogY29udGVudC53b3JkQ291bnQsXG4gICAgICBoYXNTY2hlbWE6IGNvbnRlbnQuc2NoZW1hcy5sZW5ndGggPiAwLFxuICAgICAgaGVhZGluZ0NvdW50OiBjb250ZW50LmhlYWRpbmdzLmxlbmd0aCxcbiAgICAgIGltYWdlQ291bnQ6IGNvbnRlbnQuaW1hZ2VzLmxlbmd0aCxcbiAgICAgIGltYWdlQWx0VGV4dFJhdGU6IGNhbGN1bGF0ZUltYWdlQWx0VGV4dFJhdGUoY29udGVudC5pbWFnZXMpLFxuICAgICAgcmVhZGFiaWxpdHlNZXRyaWNzOiB7XG4gICAgICAgIHNlbnRlbmNlTGVuZ3RoOiByZWFkYWJpbGl0eU1ldHJpY3Muc2VudGVuY2VMZW5ndGgsXG4gICAgICAgIHdvcmRMZW5ndGg6IHJlYWRhYmlsaXR5TWV0cmljcy53b3JkTGVuZ3RoXG4gICAgICB9XG4gICAgfVxuICB9O1xufVxuXG4vKipcbiAqIENhbGN1bGF0ZSByZWFkYWJpbGl0eSBtZXRyaWNzXG4gKi9cbmZ1bmN0aW9uIGNhbGN1bGF0ZVJlYWRhYmlsaXR5TWV0cmljcyh0ZXh0OiBzdHJpbmcpOiB7IHNlbnRlbmNlTGVuZ3RoOiBudW1iZXI7IHdvcmRMZW5ndGg6IG51bWJlciB9IHtcbiAgLy8gRGVmYXVsdCB2YWx1ZXMgZm9yIGVtcHR5IGNvbnRlbnRcbiAgaWYgKCF0ZXh0IHx8IHRleHQudHJpbSgpLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiB7IHNlbnRlbmNlTGVuZ3RoOiAwLCB3b3JkTGVuZ3RoOiAwIH07XG4gIH1cbiAgXG4gIC8vIFNwbGl0IGludG8gc2VudGVuY2VzIGFuZCB3b3Jkc1xuICBjb25zdCBzZW50ZW5jZXMgPSB0ZXh0LnNwbGl0KC9bLiE/XSsvKS5maWx0ZXIoQm9vbGVhbik7XG4gIGNvbnN0IHdvcmRzID0gdGV4dC5zcGxpdCgvXFxzKy8pLmZpbHRlcihCb29sZWFuKTtcbiAgXG4gIGlmIChzZW50ZW5jZXMubGVuZ3RoID09PSAwIHx8IHdvcmRzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiB7IHNlbnRlbmNlTGVuZ3RoOiAwLCB3b3JkTGVuZ3RoOiAwIH07XG4gIH1cbiAgXG4gIC8vIENhbGN1bGF0ZSBhdmVyYWdlIHNlbnRlbmNlIGxlbmd0aFxuICBjb25zdCBhdmdTZW50ZW5jZUxlbmd0aCA9IHdvcmRzLmxlbmd0aCAvIHNlbnRlbmNlcy5sZW5ndGg7XG4gIFxuICAvLyBDYWxjdWxhdGUgYXZlcmFnZSB3b3JkIGxlbmd0aFxuICBjb25zdCB0b3RhbENoYXJzID0gd29yZHMucmVkdWNlKChzdW0sIHdvcmQpID0+IHN1bSArIHdvcmQubGVuZ3RoLCAwKTtcbiAgY29uc3QgYXZnV29yZExlbmd0aCA9IHRvdGFsQ2hhcnMgLyB3b3Jkcy5sZW5ndGg7XG4gIFxuICByZXR1cm4ge1xuICAgIHNlbnRlbmNlTGVuZ3RoOiBNYXRoLnJvdW5kKGF2Z1NlbnRlbmNlTGVuZ3RoICogMTApIC8gMTAsXG4gICAgd29yZExlbmd0aDogTWF0aC5yb3VuZChhdmdXb3JkTGVuZ3RoICogMTApIC8gMTBcbiAgfTtcbn1cblxuLyoqXG4gKiBDYWxjdWxhdGUgaW1hZ2UgYWx0IHRleHQgcmF0ZVxuICovXG5mdW5jdGlvbiBjYWxjdWxhdGVJbWFnZUFsdFRleHRSYXRlKGltYWdlczogeyBzcmM6IHN0cmluZzsgYWx0OiBzdHJpbmcgfVtdKTogbnVtYmVyIHtcbiAgaWYgKGltYWdlcy5sZW5ndGggPT09IDApIHJldHVybiAwO1xuICBcbiAgY29uc3QgaW1hZ2VzV2l0aEFsdCA9IGltYWdlcy5maWx0ZXIoaW1nID0+IGltZy5hbHQgJiYgaW1nLmFsdC50cmltKCkubGVuZ3RoID4gMCk7XG4gIHJldHVybiBNYXRoLnJvdW5kKChpbWFnZXNXaXRoQWx0Lmxlbmd0aCAvIGltYWdlcy5sZW5ndGgpICogMTAwKTtcbn1cblxuLyoqXG4gKiBHZW5lcmF0ZSByZWNvbW1lbmRhdGlvbnMgYmFzZWQgb24gYW5hbHlzaXNcbiAqL1xuZnVuY3Rpb24gZ2VuZXJhdGVSZWNvbW1lbmRhdGlvbnMoY29udGVudDogYW55LCByZWFkYWJpbGl0eVNjb3JlOiBudW1iZXIsIHNjaGVtYVNjb3JlOiBudW1iZXIsIGhlYWRpbmdTY29yZTogbnVtYmVyKTogc3RyaW5nW10ge1xuICBjb25zdCByZWNvbW1lbmRhdGlvbnM6IHN0cmluZ1tdID0gW107XG4gIFxuICAvLyBTY2hlbWEgcmVjb21tZW5kYXRpb25zXG4gIGlmIChzY2hlbWFTY29yZSA8IDcwKSB7XG4gICAgcmVjb21tZW5kYXRpb25zLnB1c2goXCJBZGQgc3RydWN0dXJlZCBkYXRhIHVzaW5nIFNjaGVtYS5vcmcgbWFya3VwIHRvIGltcHJvdmUgQUkgdW5kZXJzdGFuZGluZyBvZiB5b3VyIGNvbnRlbnRcIik7XG4gIH1cbiAgXG4gIC8vIFJlYWRhYmlsaXR5IHJlY29tbWVuZGF0aW9uc1xuICBpZiAocmVhZGFiaWxpdHlTY29yZSA8IDcwKSB7XG4gICAgcmVjb21tZW5kYXRpb25zLnB1c2goXCJVc2Ugc2hvcnRlciBzZW50ZW5jZXMgYW5kIHNpbXBsZXIgbGFuZ3VhZ2UgdG8gaW1wcm92ZSBjb250ZW50IHJlYWRhYmlsaXR5XCIpO1xuICB9XG4gIFxuICAvLyBIZWFkaW5nIHJlY29tbWVuZGF0aW9uc1xuICBpZiAoaGVhZGluZ1Njb3JlIDwgNzApIHtcbiAgICByZWNvbW1lbmRhdGlvbnMucHVzaChcIkltcHJvdmUgY29udGVudCBvcmdhbml6YXRpb24gd2l0aCBjbGVhciBoZWFkaW5ncyBhbmQgc3ViaGVhZGluZ3NcIik7XG4gIH1cbiAgXG4gIC8vIEltYWdlIHJlY29tbWVuZGF0aW9uc1xuICBpZiAoY29udGVudC5pbWFnZXMubGVuZ3RoID4gMCAmJiBjYWxjdWxhdGVJbWFnZUFsdFRleHRSYXRlKGNvbnRlbnQuaW1hZ2VzKSA8IDgwKSB7XG4gICAgcmVjb21tZW5kYXRpb25zLnB1c2goXCJBZGQgZGVzY3JpcHRpdmUgYWx0IHRleHQgdG8gYWxsIGltYWdlcyBmb3IgYmV0dGVyIGFjY2Vzc2liaWxpdHkgYW5kIEFJIHVuZGVyc3RhbmRpbmdcIik7XG4gIH1cbiAgXG4gIC8vIENvbnRlbnQgbGVuZ3RoIHJlY29tbWVuZGF0aW9uc1xuICBpZiAoY29udGVudC53b3JkQ291bnQgPCA1MDApIHtcbiAgICByZWNvbW1lbmRhdGlvbnMucHVzaChcIkV4cGFuZCB5b3VyIGNvbnRlbnQgd2l0aCBtb3JlIGRldGFpbGVkIGluZm9ybWF0aW9uIHRvIGltcHJvdmUgY29tcHJlaGVuc2l2ZW5lc3NcIik7XG4gIH1cbiAgXG4gIC8vIEFsd2F5cyBhZGQgYSBmZXcgZ2VuZXJpYyByZWNvbW1lbmRhdGlvbnNcbiAgcmVjb21tZW5kYXRpb25zLnB1c2goXCJJbmNsdWRlIGNvbmNpc2UgYW5zd2VycyB0byBjb21tb24gcXVlc3Rpb25zIGluIHlvdXIgbmljaGVcIik7XG4gIHJlY29tbWVuZGF0aW9ucy5wdXNoKFwiVXNlIGRlc2NyaXB0aXZlIHBhZ2UgdGl0bGVzIGFuZCBtZXRhIGRlc2NyaXB0aW9uc1wiKTtcbiAgXG4gIHJldHVybiByZWNvbW1lbmRhdGlvbnM7XG59XG5cbi8qKlxuICogQ2FsY3VsYXRlIG92ZXJhbGwgc2NvcmUgdXNpbmcgYSB3ZWlnaHRlZCBhdmVyYWdlXG4gKi9cbmZ1bmN0aW9uIGNhbGN1bGF0ZU92ZXJhbGxTY29yZShiYXNpY1Njb3JlczogYW55LCBhaVNjb3JlOiBudW1iZXIpOiBudW1iZXIge1xuICAvLyBJZiBBSSBzY29yZSBpcyBhdmFpbGFibGUsIGluY2x1ZGUgaXQgaW4gdGhlIGNhbGN1bGF0aW9uXG4gIGlmIChhaVNjb3JlID4gMCkge1xuICAgIHJldHVybiBNYXRoLnJvdW5kKFxuICAgICAgKGJhc2ljU2NvcmVzLnJlYWRhYmlsaXR5ICogMC4yKSArXG4gICAgICAoYmFzaWNTY29yZXMuc2NoZW1hICogMC4yKSArXG4gICAgICAoYmFzaWNTY29yZXMuaGVhZGluZ3NTdHJ1Y3R1cmUgKiAwLjIpICtcbiAgICAgIChiYXNpY1Njb3Jlcy5xdWVzdGlvbkFuc3dlck1hdGNoICogMC4xKSArXG4gICAgICAoYWlTY29yZSAqIDAuMylcbiAgICApO1xuICB9XG4gIFxuICAvLyBPdGhlcndpc2UsIHVzZSBvbmx5IGJhc2ljIHNjb3Jlc1xuICByZXR1cm4gTWF0aC5yb3VuZChcbiAgICAoYmFzaWNTY29yZXMucmVhZGFiaWxpdHkgKiAwLjI1KSArXG4gICAgKGJhc2ljU2NvcmVzLnNjaGVtYSAqIDAuMjUpICtcbiAgICAoYmFzaWNTY29yZXMuaGVhZGluZ3NTdHJ1Y3R1cmUgKiAwLjI1KSArXG4gICAgKGJhc2ljU2NvcmVzLnF1ZXN0aW9uQW5zd2VyTWF0Y2ggKiAwLjI1KVxuICApO1xufSAiXX0=